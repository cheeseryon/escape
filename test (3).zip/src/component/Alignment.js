import React , {useState} from 'react'

const Alignment = ({dataBase , dataAlignment}) => {

    const themeAscending = () => {
        let dataAlign = [...dataBase]
        dataAlign.sort(function (a, b) {
          return a.title < b.title ? -1 : a.title > b.title ? 1 : 0;
        })
        dataAlignment(dataAlign)
      }
  
      const themeDescending = () => {
        let dataAlign = [...dataBase]
        dataAlign.sort((a, b) => {
          return a.title > b.title ? -1 : a.title < b.title ? 1 : 0;
        })
        dataAlignment(dataAlign)
      }
  
      const difficultyAscending = () => {
        let dataAlign = [...dataBase]
        dataAlign.sort((a,b) => {
          return a.difficulty < b.difficulty ? -1 : a.difficulty > b.difficulty ? 1 : 0 ;
        })
        dataAlignment(dataAlign)
      }
  
      const difficultyDescending = () => {
        let dataAlign = [...dataBase]
        dataAlign.sort((a,b) => {
          return a.difficulty > b.difficulty ? -1 : a.difficulty < b.difficulty ? 1 : 0;
        })
        dataAlignment(dataAlign)
      }
  return (
    <div>
        <div className='filter'>
            <div>정렬하기</div>
            <ul>
              <li onClick={themeAscending}>테마명 오름차순</li>
              <li onClick={themeDescending}>테마명 내림차순</li>
              <li onClick={difficultyAscending}>난이도 오름차순</li>
              <li onClick={difficultyDescending}>난이도 내림차순</li>
            </ul>
          </div>
    </div>
  )
}

export default Alignment
