const initialState = {
    areaName: '',
    subAreaName: '',
    genreName: '',
    modalLike: '',
    modalItemId:[],
    likeToggle:'false',
    cardItemId:[]
};


function reducer(state = initialState, action) {
    const { type, payload } = action;

    console.log(state.cardItemId)
    console.log(state.modalItemId)

    switch (type) {
        case "GENRE_SELECT":   
            return {               
                ...state,
                genreName: payload.genreName,
            }
        
        case "AREA_SELECT":
            return {
                ...state,
                areaName : payload.areaName,
                subAreaName: '',
                genreName: ''
            }

        case "SUBAREA_SELECT":  
            return {               
                ...state,
                subAreaName: payload.subAreaName,
            }

        case "MODAL_LIKE":
            return {
                ...state,
                likeToggle: (state.likeToggle == 'false') ? 'true' : 'false'
            }
        case "MODAL_ID":
            return {
                ...state,
                modalItemId : payload.modalItemId
            }

        case "CARD_LIKE":
            return {
                ...state,
                likeToggle: (state.likeToggle == 'false') ? 'true' : 'false'
            };
        
        case "CARD_ID":
            return {
                ...state,
                cardItemId: [...state.cardItemId, payload.cardItemId]
                   /*  (state.cardItemId.filter((item) => item.cardItemId !== payload.cardItemId))
                    payload.cardItemId] */
            }

        default:
            return state;
    }
}

export default reducer;
