import React from 'react'
import './style.css'
import { Link } from 'react-router-dom'

const ItemList = (props) => {
  return (
    <Link to={'/page/' + props.item.id}>
      <div className='itemList'>      
        <figure>
          <img className='img' src={process.env.PUBLIC_URL + props.item.img} alt={props.item.imgAlt} />
        </figure>
        <p className='name'>{props.item.name}</p>
        <p className='genre'>{props.item.genre}</p>
        <p className='store'>{props.item.store}</p>
      </div>
    </Link>
  )
}

export default ItemList
