import React from 'react'
import './style.css'

const Footer = () => {
  return (
    <div>
      <div className='footerBox'>
        <h4>풋어</h4>
      </div>
    </div>
  )
}

export default Footer
