import React , { useState , useEffect , useRef , useCallback }from 'react'
import { Swiper, SwiperSlide } from 'swiper/react';
import ProductCard from './ProductCard'
import 'swiper/css';
import 'swiper/css/navigation';
import { Navigation,Keyboard, } from 'swiper/modules';

const StoreInfo = ({item , prodList , postItem}) => {
    const getItem = (theme) => {
        postItem(theme)
    }
    const [storeTheme , setStoreTheme ] = useState([])
    let fiteredTheme = prodList.filter((theme) => 
        theme.store.includes(item.store) && 
        theme.title !== item.title
    )
    useEffect(() => {
        setStoreTheme(fiteredTheme)
    },[postItem])

    let array = { lat: -34.397, lng: 150.644}
    const mapRef = useRef(null)
    const initMap = useCallback(() => {
        new window.google.maps.Map(mapRef.current, {
            center: array ,
            zoom : 8
        });
    }, [mapRef])

    useEffect(() => {
        initMap();
    }, [initMap])




    return (
        <div className="storeInfoWrap">
            <div className="storeName">
                <p>{item?.store}</p>
                <p>주소 : </p>
            </div>
            <div className='storeThemeList'>
                    <p>매장의 다른테마</p> 
                <Swiper
                    cssMode={true}
                    navigation={true}
                    keyboard={true}
                    mousewheel={false}
                    modules={[Navigation , Keyboard]}
                    className="mySwiper"
                >
                    {
                        storeTheme.map((menu , idx) => (
                            <SwiperSlide className="storeThemeItem"><ProductCard item={menu} key={idx} getItem={getItem}/></SwiperSlide>
                        ))
                    }
                </Swiper>
            </div>

            <div className="storeMap">
                <div ref={mapRef}></div>
            </div>
        </div>
    )
}

export default StoreInfo
