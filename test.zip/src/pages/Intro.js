import React from 'react'
import { Link } from 'react-router-dom'
import './style.css'


const Intro = () => {
  return (
    <>
      <div className='intro'>
        <Link to='work' style={{ textDecoration: "none" }}>
          <div className='mainBg'>
            <h1>또!방탈출</h1>
            <br></br>
            <p>보러가기</p>
          </div>
        </Link>
      </div>
    </>
  )
}

export default Intro
