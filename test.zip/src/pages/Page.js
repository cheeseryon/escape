import React from 'react'
import Header from '../component/Header'
import Footer from '../component/Footer'
import Info from '../component/Info'
import { useState } from 'react'
import data from '../data'
import './style.css'

const Page = () => {
  let [item] = useState(data);
  return (
    <div>
        <Header />
        <Info item={item} />
        <Footer />
    </div>
  )
}

export default Page
