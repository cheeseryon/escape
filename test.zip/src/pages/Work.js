import React from 'react'
import Header from '../component/Header'
import Footer from '../component/Footer'
import ItemList from '../component/ItemList'
import { useState } from 'react'
import data from '../data'
import './style.css'

const Work = () => {
  let [item] = useState(data);
  return (
    <>
      <Header /> 
      <div className='itemBox'>
        {
          item.map((a, i) => {
            return (              
              <ItemList item={item[i]} i = {i} key={a.id}></ItemList>
            )
          })
        }
      </div>
      <Footer />
    </>
  )
}

export default Work
