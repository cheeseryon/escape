import React , { useState , useEffect , useRef } from 'react';
import '../App.css'
import key from '../img/key.png'
import star from '../img/star.png'
import starGray from '../img/star_gray.png'
import xIcon from '../img/xIcon.png'
import storeIcon from '../img/store.png'
import closeIcon from '../img/close.png'
import likeIcon from '../img/like.png'
import { useDispatch , useSelector } from 'react-redux'

const ProductModal = ({item , hideModal}) => {
    const modalClose = () => {
        hideModal(false)
    }

    let dispatch = useDispatch()
    let cardLike = useSelector(state => state.cardLike)
    let cardItemId = useSelector(state => state.cardItemId)  

    const [modalLike , setModalLike ] = useState(false)

    useEffect(() => {
        if (item.id === cardItemId) {
            setModalLike(cardLike)
        }
    }, [cardLike]);

    let modalItemId = item.id
    const likeClick = () => {
        setModalLike(!modalLike)
        dispatch ({type:"MODAL_LIKE" , payload:{modalLike:!modalLike}})
        dispatch ({type:"MODAL_ID" , payload:{modalItemId}})
    }


    const [clicked, setClicked] = useState([false,false,false,false,false]);
    const array = [0,1,2,3,4]
    const starClick = () => {

    }

    return (
        <div className='itemDetail'>              
            <div className="itemBg" onClick={modalClose}/>
            <div className="itemWrap">             
                <div className='itemInfo'>  
                    <h2>상세정보</h2>
                    <section className="topInfoSec">                
                        <div className='imgArea'>
                            <img className='img' src={process.env.PUBLIC_URL + item?.img} alt={item?.imgAlt} />
                        </div>
                        <div className='textArea'>
                            <p className='title'>{item?.title}</p>
                            <p className='genre'>{item?.genre[0]}</p>
                            <p className='store'>{item?.store}</p>

                            <div className='evaluation'>
                                <p className='difficulty'>
                                    <span className='keyIcon'><img src={key} alt="열쇠" /></span>
                                    <span className='xIcon'><img src={xIcon} alt="" /></span>
                                    <span className='num'>{item?.difficulty}</span>
                                </p>
                                <p className='score'>
                                    <span className='starIcon'><img src={star} alt="별" /></span>
                                    <span className='num'>4.5</span>
                                </p>
                            </div>
                            <div className='themeInfo'>
                                <h4>테마 설명</h4>
                                <p className='themeInfoText'>
                                {
                                    item?.info.split('\n').map((text, index) => (
                                    <React.Fragment key={index}>
                                        {text}
                                        <br />
                                    </React.Fragment>
                                    ))
                                }
                                </p>
                            </div>
                        </div>
                    </section>

                    <section className='bottomInfoSec'>
                        <ul className='tabArea'>
                            <li className='review'>리뷰</li>
                        </ul>
                        {/* <p className='caution'>스포일러나 근거없는 비방글은 삭제됩니다</p>          */}              
                        <div className='reviewArea'>
                            <div className="reviewTop">
                                <p>4.5 (264)</p>                             
                                <ul class="starArea">
                                    {
                                    array.map((item,idx)=> (
                                        <li key={idx}
                                            onClick={() => starClick(idx)}
                                            className={clicked[idx] && 'black'}>
                                            <img src={starGray} alt="별" />
                                        </li>
                                    ))
                                    }
                                </ul>    
                            </div>

                            <div className="reviewBottom">
                                <ul>
                                    <li className='reviewItem'>
                                        <div>
                                            <div className="userName">메로나</div>
                                            <div className='evaluation'>
                                                <p className='difficulty'>
                                                    <span className='keyIcon'><img src={key} alt="열쇠" /></span>
                                                    <span className='xIcon'><img src={xIcon} alt="" /></span>
                                                    <span className='num'>{item?.difficulty}</span>
                                                </p>
                                                <p className='score'>
                                                    <span className='starIcon'><img src={star} alt="별" /></span>
                                                    <span className='num'>4.5</span>
                                                </p>
                                            </div>
                                            <div className=""></div>
                                            <div className=""></div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </section>
                </div>

                <div className='btnArea'>
                    <span className={`like ${modalLike ? 'on' : ''}`} onClick={likeClick}><span /></span>
                    <span className='storeLink'><img src={storeIcon}></img></span>
                    <span className='modalCloseBtn' onClick={modalClose}><img src={closeIcon}></img></span>
                </div>
            </div> 


             
        </div>
    )
}

export default ProductModal
