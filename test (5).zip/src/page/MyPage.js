import React from 'react'
import { useSelector } from 'react-redux'
import dataBase from '../db/db.json'
import Navbar from '../component/Navbar'


const MyPage = () => {



  return (
    <div className="myPage">
      <Navbar />
      <div className="myPageContent">
        <div className="contHead">
          <div className="inner">
            <span>좋아요 목록</span>
          </div>
        </div>

        <div>
            <div className="inner">
                <div className="likeThemeList">

                </div>
            </div>
        </div>
      </div>
    </div>
  )
}

export default MyPage
